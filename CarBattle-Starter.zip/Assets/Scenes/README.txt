Create CarBattle.unity here from Unity.
