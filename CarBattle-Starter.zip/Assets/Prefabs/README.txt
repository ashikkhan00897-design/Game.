Save your car, bullet, and FX prefabs here.
