using UnityEngine;
using UnityEngine.EventSystems;

public class Joystick : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IDragHandler
{
    public RectTransform handle;
    public float maxRadius = 80f;
    Vector2 startPos;
    bool dragging;
    Vector2 value;

    public Vector2 Value => value; // x = steer (-1..1), y = throttle (0..1)

    public void OnPointerDown(PointerEventData e)
    {
        dragging = true;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            (RectTransform)transform, e.position, e.pressEventCamera, out startPos);
        SetHandle(Vector2.zero);
    }

    public void OnDrag(PointerEventData e)
    {
        Vector2 pos;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            (RectTransform)transform, e.position, e.pressEventCamera, out pos);
        Vector2 delta = pos - startPos;
        delta = Vector2.ClampMagnitude(delta, maxRadius);
        SetHandle(delta);
        value = new Vector2(delta.x / maxRadius, Mathf.Clamp01(delta.y / maxRadius));
    }

    public void OnPointerUp(PointerEventData e)
    {
        dragging = false;
        SetHandle(Vector2.zero);
        value = Vector2.zero;
    }

    void SetHandle(Vector2 localOffset)
    {
        if (handle) handle.anchoredPosition = localOffset;
    }
}
