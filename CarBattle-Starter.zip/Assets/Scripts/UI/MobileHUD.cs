using UnityEngine;

public class MobileHUD : MonoBehaviour
{
    public Joystick joystick;
    public CarController car;
    public UnityEngine.UI.Button brakeButton;

    void Awake()
    {
        if (!car) car = FindObjectOfType<CarController>();
        if (brakeButton) brakeButton.onClick.AddListener(TapBrake);
    }

    void Update()
    {
        if (!car || !joystick) return;
        Vector2 v = joystick.Value;
        car.steer = Mathf.Clamp(v.x, -1f, 1f);
        car.throttle = Mathf.Clamp01(v.y);
        // soft auto-brake when not throttling
        car.brake = v.y < 0.1f ? 0.25f : 0f;
    }

    void TapBrake()
    {
        if (!car) return;
        car.brake = 1f;
    }
}
