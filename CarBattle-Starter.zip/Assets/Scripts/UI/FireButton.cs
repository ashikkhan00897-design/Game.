using UnityEngine;
using UnityEngine.EventSystems;

public class FireButton : MonoBehaviour, IPointerDownHandler
{
    public WeaponSystem weapon;

    public void OnPointerDown(PointerEventData eventData)
    {
        if (weapon) weapon.Fire();
    }
}
