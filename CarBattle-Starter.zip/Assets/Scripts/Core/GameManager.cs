using UnityEngine;

public class GameManager : MonoBehaviour
{
    public Transform playerSpawn;
    public Transform[] enemySpawns;

    public Health player;
    public Health[] enemies;

    public void HandleDeath(Health h)
    {
        // very simple respawn logic
        if (h == player && playerSpawn)
        {
            var rb = h.GetComponent<Rigidbody>();
            if (rb) { rb.velocity = Vector3.zero; rb.angularVelocity = Vector3.zero; }
            h.transform.SetPositionAndRotation(playerSpawn.position, playerSpawn.rotation);
            h.HealFull();
        }
        else
        {
            for (int i = 0; i < enemies.Length; i++)
            {
                if (enemies[i] == h && enemySpawns != null && enemySpawns.Length > 0)
                {
                    var t = enemySpawns[i % enemySpawns.Length];
                    var rb = h.GetComponent<Rigidbody>();
                    if (rb) { rb.velocity = Vector3.zero; rb.angularVelocity = Vector3.zero; }
                    h.transform.SetPositionAndRotation(t.position, t.rotation);
                    h.HealFull();
                    break;
                }
            }
        }
    }
}
