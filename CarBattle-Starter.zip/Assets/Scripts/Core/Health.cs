using UnityEngine;
using UnityEngine.Events;

public class Health : MonoBehaviour
{
    public float maxHp = 100f;
    public float hp = 100f;
    public UnityEvent onDie;

    public void TakeDamage(float dmg)
    {
        hp -= dmg;
        if (hp <= 0f)
        {
            hp = 0f;
            onDie?.Invoke();
            // simple respawn for demo
            var gm = FindObjectOfType<GameManager>();
            if (gm) gm.HandleDeath(this);
        }
    }

    public void HealFull()
    {
        hp = maxHp;
    }
}
