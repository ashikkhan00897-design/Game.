using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class CarController : MonoBehaviour
{
    [Header("Wheel Colliders")]
    public WheelCollider wheelFL;
    public WheelCollider wheelFR;
    public WheelCollider wheelRL;
    public WheelCollider wheelRR;

    [Header("Wheel Visuals (Optional)")]
    public Transform wheelFLVisual;
    public Transform wheelFRVisual;
    public Transform wheelRLVisual;
    public Transform wheelRRVisual;

    [Header("Drive")]
    public float maxMotorTorque = 2500f; // torque per driven wheel
    public float maxSteerAngle = 30f;
    public float maxBrakeTorque = 3500f;
    public AnimationCurve steerCurve = AnimationCurve.EaseInOut(0, 1, 100, 0.6f); // less steering at high speed
    public bool rearWheelDrive = true;
    public bool frontWheelDrive = false;

    [Header("Stability/Drift")]
    public float antiRoll = 8000f;
    public float tractionControl = 0.6f; // 0..1 (1 = full grip)
    public float driftBrakeMultiplier = 1.5f;

    [Header("Input")]
    [Range(-1, 1)] public float steer;
    [Range(0, 1)] public float throttle;
    [Range(0, 1)] public float brake;

    [Header("Misc")]
    public Transform centerOfMass;
    private Rigidbody rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        if (centerOfMass) rb.centerOfMass = transform.InverseTransformPoint(centerOfMass.position);
        SetupFriction(wheelFL);
        SetupFriction(wheelFR);
        SetupFriction(wheelRL);
        SetupFriction(wheelRR);
    }

    void FixedUpdate()
    {
        float speedKmh = rb.velocity.magnitude * 3.6f;
        float steerAtSpeed = maxSteerAngle * steerCurve.Evaluate(speedKmh);
        wheelFL.steerAngle = steer * steerAtSpeed;
        wheelFR.steerAngle = steer * steerAtSpeed;

        // motor torque
        float torque = maxMotorTorque * throttle;
        if (rearWheelDrive)
        {
            wheelRL.motorTorque = torque;
            wheelRR.motorTorque = torque;
        }
        if (frontWheelDrive)
        {
            wheelFL.motorTorque = torque;
            wheelFR.motorTorque = torque;
        }

        // braking
        float brakeTorque = maxBrakeTorque * brake * (driftBrakeMultiplier > 1f ? driftBrakeMultiplier : 1f);
        wheelFL.brakeTorque = brakeTorque;
        wheelFR.brakeTorque = brakeTorque;
        wheelRL.brakeTorque = brakeTorque;
        wheelRR.brakeTorque = brakeTorque;

        ApplyAntiRoll(wheelFL, wheelFR);
        ApplyAntiRoll(wheelRL, wheelRR);

        // visuals
        UpdateWheelVisual(wheelFL, wheelFLVisual);
        UpdateWheelVisual(wheelFR, wheelFRVisual);
        UpdateWheelVisual(wheelRL, wheelRLVisual);
        UpdateWheelVisual(wheelRR, wheelRRVisual);
    }

    void SetupFriction(WheelCollider wc)
    {
        if (!wc) return;
        WheelFrictionCurve f = wc.forwardFriction;
        f.asymptoteSlip = 0.8f;
        f.extremumSlip = 0.4f;
        f.stiffness = Mathf.Lerp(0.8f, 1.6f, tractionControl);
        wc.forwardFriction = f;

        WheelFrictionCurve s = wc.sidewaysFriction;
        s.asymptoteSlip = 0.6f;
        s.extremumSlip = 0.3f;
        s.stiffness = Mathf.Lerp(0.8f, 1.5f, tractionControl);
        wc.sidewaysFriction = s;
    }

    void ApplyAntiRoll(WheelCollider left, WheelCollider right)
    {
        WheelHit hit;
        float travelL = 1.0f;
        float travelR = 1.0f;

        bool groundedL = left.GetGroundHit(out hit);
        if (groundedL) travelL = (-left.transform.InverseTransformPoint(hit.point).y - left.radius) / left.suspensionDistance;
        bool groundedR = right.GetGroundHit(out hit);
        if (groundedR) travelR = (-right.transform.InverseTransformPoint(hit.point).y - right.radius) / right.suspensionDistance;

        float antiRollForce = (travelL - travelR) * antiRoll;

        if (groundedL) rb.AddForceAtPosition(left.transform.up * -antiRollForce, left.transform.position);
        if (groundedR) rb.AddForceAtPosition(right.transform.up * antiRollForce, right.transform.position);
    }

    void UpdateWheelVisual(WheelCollider col, Transform visual)
    {
        if (!col || !visual) return;
        Vector3 pos;
        Quaternion rot;
        col.GetWorldPose(out pos, out rot);
        visual.SetPositionAndRotation(pos, rot);
    }
}
