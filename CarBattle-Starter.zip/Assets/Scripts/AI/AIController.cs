using UnityEngine;

[RequireComponent(typeof(CarController))]
public class AIController : MonoBehaviour
{
    public Transform target;
    public float desiredSpeed = 40f;
    public float keepDistance = 15f;
    public float shootDistance = 35f;
    public float steerAggression = 2.2f;
    public float brakeAggression = 0.8f;

    CarController car;
    WeaponSystem weapon;
    Rigidbody rb;

    void Awake()
    {
        car = GetComponent<CarController>();
        weapon = GetComponent<WeaponSystem>();
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        if (!target) return;
        Vector3 toT = (target.position - transform.position);
        float dist = toT.magnitude;
        Vector3 dir = toT.normalized;

        // aim to steer toward the target with a bit of look-ahead
        Vector3 local = transform.InverseTransformDirection(dir);
        float steer = Mathf.Clamp(local.x * steerAggression, -1f, 1f);

        // throttle/brake logic
        float speed = rb.velocity.magnitude;
        float throttle = Mathf.Clamp01(desiredSpeed - speed) * 0.6f;
        float brake = dist < keepDistance ? brakeAggression : 0f;

        car.steer = steer;
        car.throttle = throttle;
        car.brake = brake;

        if (weapon && dist <= shootDistance)
        {
            // naive firing straight
            weapon.Fire();
        }
    }
}
