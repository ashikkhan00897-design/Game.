using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed = 60f;
    public float life = 4f;
    public float damage = 20f;
    public Rigidbody rb;
    public GameObject hitFx;

    float t;

    void OnEnable()
    {
        t = 0f;
        if (!rb) rb = GetComponent<Rigidbody>();
        if (rb) rb.velocity = transform.forward * speed;
    }

    void Update()
    {
        t += Time.deltaTime;
        if (t >= life) gameObject.SetActive(false);
    }

    void OnCollisionEnter(Collision c)
    {
        var h = c.collider.GetComponentInParent<Health>();
        if (h) h.TakeDamage(damage);
        if (hitFx) Instantiate(hitFx, c.contacts[0].point, Quaternion.identity);
        gameObject.SetActive(false);
    }
}
