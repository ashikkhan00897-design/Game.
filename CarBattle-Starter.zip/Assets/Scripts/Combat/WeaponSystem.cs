using UnityEngine;

public class WeaponSystem : MonoBehaviour
{
    public Transform muzzle;
    public ObjectPool pool;
    public float fireRate = 8f; // per second
    float cooldown;

    void Update()
    {
        cooldown -= Time.deltaTime;
    }

    public void Fire()
    {
        if (cooldown > 0f || !muzzle || !pool) return;
        var go = pool.Spawn(muzzle.position, muzzle.rotation);
        cooldown = 1f / fireRate;
    }
}
