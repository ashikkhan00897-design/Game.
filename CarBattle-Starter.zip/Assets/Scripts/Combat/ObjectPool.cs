using System.Collections.Generic;
using UnityEngine;

public class ObjectPool : MonoBehaviour
{
    public GameObject prefab;
    public int initial = 16;
    private readonly Queue<GameObject> pool = new Queue<GameObject>();

    void Awake()
    {
        for (int i = 0; i < initial; i++)
            pool.Enqueue(Create());
    }

    GameObject Create()
    {
        var go = Instantiate(prefab, transform);
        go.SetActive(false);
        return go;
    }

    public GameObject Spawn(Vector3 pos, Quaternion rot)
    {
        GameObject go = pool.Count > 0 ? pool.Dequeue() : Create();
        go.transform.SetPositionAndRotation(pos, rot);
        go.SetActive(true);
        return go;
    }

    public void Despawn(GameObject go)
    {
        go.SetActive(false);
        pool.Enqueue(go);
    }
}
