// Shadowdrop Mini — Top‑Down Battle Royale Prototype
(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  let W, H;
  function resize() {
    W = Math.floor(window.innerWidth);
    H = Math.floor(window.innerHeight);
    canvas.width = Math.floor(W * dpr);
    canvas.height = Math.floor(H * dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  window.addEventListener('resize', resize);
  resize();
  canvas.focus();

  // World
  const WORLD = { size: 2800, half: 1400 };
  // Safe zone phases (8)
  const phases = [
    { duration: 22, shrink: 10, radius: 1200, dmg: 0.1 },
    { duration: 20, shrink: 10, radius: 950, dmg: 0.2 },
    { duration: 20, shrink: 9, radius: 750, dmg: 0.5 },
    { duration: 20, shrink: 8, radius: 570, dmg: 1.2 },
    { duration: 18, shrink: 8, radius: 420, dmg: 2.5 },
    { duration: 16, shrink: 7, radius: 290, dmg: 5.0 },
    { duration: 15, shrink: 7, radius: 180, dmg: 8.0 },
    { duration: 15, shrink: 7, radius: 110, dmg: 12.0 },
  ];

  // RNG helpers
  const rand = (a,b)=> a + Math.random()*(b-a);
  const rint = (a,b)=> Math.floor(rand(a,b+1));
  const clamp = (v,a,b)=> Math.max(a, Math.min(b,v));

  // Camera
  const cam = { x:0, y:0, shake:0 };

  // Player & bots
  const TOTAL = 40; // total competitors
  const entities = [];
  const bullets = [];
  const loot = [];
  const corpses = [];
  const TEAM_NONE = -1;

  // Input
  const keys = {};
  const mouse = { x:0, y:0, down:false };

  canvas.addEventListener('mousemove', (e)=>{
    const rect = canvas.getBoundingClientRect();
    mouse.x = (e.clientX - rect.left);
    mouse.y = (e.clientY - rect.top);
  });
  canvas.addEventListener('mousedown', ()=> mouse.down = true);
  canvas.addEventListener('mouseup', ()=> mouse.down = false);
  window.addEventListener('keydown', (e)=> { keys[e.key.toLowerCase()] = true; });
  window.addEventListener('keyup',   (e)=> { keys[e.key.toLowerCase()] = false; });

  // Entity factory
  function makeEntity(x,y, isPlayer=false) {
    return {
      x, y,
      vx:0, vy:0,
      dir:0,
      speed: isPlayer ? 150 : rand(120,150),
      sprint: 1.6,
      dashCD:0,
      r: 12,
      color: isPlayer ? '#29C2B6' : '#c8d4f0',
      hp: 100,
      alive: true,
      isPlayer,
      targetId: -1,
      fireCD: 0,
      kills: 0,
      vision: 450,
      gun: { dmg: 12, spread: 0.06, range: 560, rof: 7, speed: 560 }, // bullets/sec-ish
      aimNoise: isPlayer? 0 : 0.12,
      name: isPlayer? 'You' : 'Bot ' + rint(100,999),
    };
  }

  // Spawn
  function randEdgeSpawn() {
    // spawn along edges to simulate plane drop
    const s = WORLD.size;
    const side = rint(0,3);
    let x,y;
    if (side===0) { x = rand(-WORLD.half, WORLD.half); y = -WORLD.half+40; }
    if (side===1) { x = WORLD.half-40; y = rand(-WORLD.half, WORLD.half); }
    if (side===2) { x = rand(-WORLD.half, WORLD.half); y = WORLD.half-40; }
    if (side===3) { x = -WORLD.half+40; y = rand(-WORLD.half, WORLD.half); }
    return {x,y};
  }

  // Create player
  const sp = randEdgeSpawn();
  const player = makeEntity(sp.x, sp.y, true);
  entities.push(player);

  // Create bots
  for (let i=1;i<TOTAL;i++) {
    const p = randEdgeSpawn();
    entities.push(makeEntity(p.x, p.y, false));
  }

  // Loot (medkits & better guns)
  for (let i=0;i<120;i++) {
    loot.push({
      x: rand(-WORLD.half+50, WORLD.half-50),
      y: rand(-WORLD.half+50, WORLD.half-50),
      type: Math.random()<0.65 ? 'med' : 'gun',
      taken: false
    });
  }

  // Safe zone center
  let zone = { x: rand(-300,300), y: rand(-300,300), r: phases[0].radius };
  let zoneTarget = { x: zone.x, y: zone.y, r: zone.r };
  let phaseIdx = 0;
  let phaseTime = 0;
  let shrinking = false;

  function pickNextZone() {
    const p = clamp(phaseIdx, 0, phases.length-1);
    const ph = phases[p];
    const shift = rand(0.15, 0.45);
    // random shift within current radius
    const ang = rand(0, Math.PI*2);
    const dist = zone.r * shift;
    zoneTarget.x = clamp(zone.x + Math.cos(ang)*dist, -WORLD.half+ph.radius, WORLD.half-ph.radius);
    zoneTarget.y = clamp(zone.y + Math.sin(ang)*dist, -WORLD.half+ph.radius, WORLD.half-ph.radius);
    zoneTarget.r = ph.radius;
  }
  pickNextZone();

  // UI refs
  const uiAlive = document.getElementById('alive');
  const uiKills = document.getElementById('kills');
  const uiPhase = document.getElementById('phase');
  const uiStorm = document.getElementById('storm');
  const hpBar = document.getElementById('hp');
  const end = document.getElementById('end');
  const endTitle = document.getElementById('endTitle');
  const endNote = document.getElementById('endNote');
  const minimap = document.getElementById('minimap');
  const mctx = minimap.getContext('2d');
  let miniZoom = 1; // toggle with M

  window.addEventListener('keydown', (e)=>{
    if (e.key.toLowerCase()==='m') miniZoom = (miniZoom===1? 2:1);
  });

  function update(dt) {
    // Phases
    phaseTime += dt;
    const ph = phases[phaseIdx];
    uiPhase.textContent = (phaseIdx+1) + "/" + phases.length;
    uiStorm.textContent = ph.dmg.toFixed(1);

    if (!shrinking && phaseTime>=ph.duration) {
      shrinking = true;
      phaseTime = 0;
    }
    if (shrinking) {
      // linearly move center & shrink radius over ph.shrink seconds
      const t = clamp(phaseTime / ph.shrink, 0, 1);
      zone.x += (zoneTarget.x - zone.x) * 0.02;
      zone.y += (zoneTarget.y - zone.y) * 0.02;
      zone.r += (zoneTarget.r - zone.r) * 0.02;
      if (phaseTime>=ph.shrink) {
        // next phase
        shrinking = false;
        phaseIdx = Math.min(phaseIdx+1, phases.length-1);
        phaseTime = 0;
        pickNextZone();
      }
    }

    // Entities logic
    const aliveList = entities.filter(e=>e.alive);
    uiAlive.textContent = aliveList.length;

    // Camera follow player
    cam.x += ((player.x - cam.x) * 6 * dt);
    cam.y += ((player.y - cam.y) * 6 * dt);

    // Player control
    if (player.alive) {
      const mx = (mouse.x) - W/2;
      const my = (mouse.y) - H/2;
      player.dir = Math.atan2(my, mx);
      let imx = 0, imy = 0;
      if (keys['w']) imy -= 1;
      if (keys['s']) imy += 1;
      if (keys['a']) imx -= 1;
      if (keys['d']) imx += 1;
      let mag = Math.hypot(imx,imy);
      if (mag>0) { imx/=mag; imy/=mag; }
      let spd = player.speed * (keys['shift']? player.sprint : 1);
      player.vx = imx * spd;
      player.vy = imy * spd;
      if (keys[' '] && player.dashCD<=0) {
        // short dash
        const dash = 280;
        player.x += (imx||Math.cos(player.dir)) * dash;
        player.y += (imy||Math.sin(player.dir)) * dash;
        player.dashCD = 1.0;
      }
      player.dashCD -= dt;

      if (mouse.down) tryFire(player, player.dir, true);
    }

    // Bot AI
    for (const e of entities) {
      if (!e.alive || e.isPlayer) continue;
      // choose target in vision: nearest alive (prefer player)
      let best = null;
      let bestD = Infinity;
      for (const t of entities) {
        if (!t.alive || t===e) continue;
        const d = Math.hypot(t.x-e.x, t.y-e.y);
        if (d<bestD && d < e.vision) { best = t; bestD = d; }
      }
      // move: toward safe center or strafe around target
      const inner = Math.hypot(e.x-zone.x, e.y-zone.y) < zone.r*0.85;
      let ax=0, ay=0;
      if (best) {
        const ang = Math.atan2(best.y-e.y, best.x-e.x) + rand(-0.5,0.5)*0.1;
        ax = Math.cos(ang); ay = Math.sin(ang);
        // occasionally strafe
        if (Math.random()<0.02) { const s = rand(-1,1); ax += -ay*s*0.6; ay += ax*s*0.6; }
        // fire if in range
        if (bestD < e.gun.range*0.9) {
          tryFire(e, Math.atan2(best.y-e.y, best.x-e.x) + rand(-e.aimNoise,e.aimNoise), false);
        }
      } else {
        // move to safe center
        const ang = Math.atan2(zone.y-e.y, zone.x-e.x);
        ax = Math.cos(ang); ay = Math.sin(ang);
        // wander
        ax += rand(-0.3,0.3); ay += rand(-0.3,0.3);
      }
      const m = Math.hypot(ax,ay)||1;
      e.vx = ax/m * e.speed * (inner? 0.9:1.2);
      e.vy = ay/m * e.speed * (inner? 0.9:1.2);
    }

    // Integrate motion and clamp to world
    for (const e of entities) {
      if (!e.alive) continue;
      e.x += e.vx*dt;
      e.y += e.vy*dt;
      e.x = clamp(e.x, -WORLD.half+10, WORLD.half-10);
      e.y = clamp(e.y, -WORLD.half+10, WORLD.half-10);

      // storm damage
      const dz = Math.hypot(e.x-zone.x, e.y-zone.y) - zone.r;
      if (dz>0) e.hp -= phases[phaseIdx].dmg * dt * Math.min(6, 1 + dz*0.01);

      // pickup loot in proximity
      for (const it of loot) {
        if (it.taken) continue;
        const d = Math.hypot(e.x-it.x, e.y-it.y);
        if (d < 18) {
          it.taken = true;
          if (it.type==='med') e.hp = Math.min(100, e.hp + 35);
          else {
            // upgrade gun slightly
            e.gun.dmg += 3;
            e.gun.spread = Math.max(0.03, e.gun.spread - 0.01);
            e.gun.range += 50;
          }
        }
      }

      if (e.hp<=0 && e.alive) {
        e.alive = false;
        corpses.push({x:e.x,y:e.y,t:0});
      }
    }

    // Bullets
    for (const b of bullets) {
      if (b.dead) continue;
      b.x += Math.cos(b.dir)*b.speed*dt;
      b.y += Math.sin(b.dir)*b.speed*dt;
      b.life -= dt;
      if (b.life<=0) { b.dead = true; continue; }
      // hit test
      for (const e of entities) {
        if (!e.alive) continue;
        if (e===b.owner) continue;
        const d = Math.hypot(e.x-b.x, e.y-b.y);
        if (d < e.r) {
          e.hp -= b.dmg;
          b.dead = true;
          if (e.hp<=0) {
            // award kill
            if (b.owner) {
              b.owner.kills = (b.owner.kills||0)+1;
              if (b.owner.isPlayer) cam.shake = 6;
            }
          } else {
            if (b.owner && b.owner.isPlayer) cam.shake = Math.max(cam.shake, 3);
          }
          break;
        }
      }
      // out of world
      if (Math.abs(b.x)>WORLD.half || Math.abs(b.y)>WORLD.half) b.dead = true;
    }

    // Cleanup
    for (let i=bullets.length-1;i>=0;i--) if (bullets[i].dead) bullets.splice(i,1);
    for (let i=corpses.length-1;i>=0;i--) { corpses[i].t+=dt; if (corpses[i].t>20) corpses.splice(i,1); }

    // End conditions
    if (!player.alive || aliveList.length===1) {
      showEnd(player.alive && aliveList[0]===player);
    }

    // UI updates
    uiKills.textContent = player.kills;
    hpBar.style.width = Math.max(0, Math.floor(2*player.hp)) + "px";
  }

  function tryFire(e, dir, isPlayer) {
    if (e.fireCD>0) return;
    e.fireCD = 1/ e.gun.rof;
    const spread = e.gun.spread*(isPlayer? 1:1.2);
    const d = dir + rand(-spread, spread);
    bullets.push({
      x: e.x + Math.cos(d)* (e.r+2),
      y: e.y + Math.sin(d)* (e.r+2),
      dir: d,
      speed: e.gun.speed,
      life: e.gun.range / e.gun.speed,
      dmg: e.gun.dmg,
      owner: e,
    });
  }

  let ended = false;
  function showEnd(victory) {
    if (ended) return;
    ended = true;
    end.style.display = 'grid';
    endTitle.textContent = victory? "Victory!" : "Defeat";
    endNote.textContent = victory? `You won with ${player.kills} kill(s).` : `You placed #${entities.filter(e=>e.alive).length+1}. Kills: ${player.kills}`;
  }

  // Render
  function draw(dt) {
    // background grid
    ctx.fillStyle = '#0b0e13';
    ctx.fillRect(0,0,W,H);

    // camera transform
    ctx.save();
    // shake
    if (cam.shake>0) {
      cam.shake -= 10*dt;
      const sx = rand(-cam.shake, cam.shake);
      const sy = rand(-cam.shake, cam.shake);
      ctx.translate(Math.floor(W/2 - cam.x + sx), Math.floor(H/2 - cam.y + sy));
    } else {
      ctx.translate(Math.floor(W/2 - cam.x), Math.floor(H/2 - cam.y));
    }

    // draw world bounds
    ctx.strokeStyle = '#1a2333';
    ctx.lineWidth = 2;
    ctx.strokeRect(-WORLD.half, -WORLD.half, WORLD.size, WORLD.size);

    // grid
    ctx.strokeStyle = '#111827';
    ctx.lineWidth = 1;
    const step = 100;
    ctx.beginPath();
    for (let x=-WORLD.half; x<=WORLD.half; x+=step) {
      ctx.moveTo(x, -WORLD.half); ctx.lineTo(x, WORLD.half);
    }
    for (let y=-WORLD.half; y<=WORLD.half; y+=step) {
      ctx.moveTo(-WORLD.half, y); ctx.lineTo(WORLD.half, y);
    }
    ctx.stroke();

    // zone
    ctx.fillStyle = 'rgba(41,194,182,0.06)';
    ctx.beginPath();
    ctx.arc(zone.x, zone.y, zone.r, 0, Math.PI*2);
    ctx.fill();
    ctx.strokeStyle = '#29C2B6';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(zone.x, zone.y, zone.r, 0, Math.PI*2);
    ctx.stroke();

    // corpses
    for (const c of corpses) {
      ctx.fillStyle = 'rgba(237,106,90,0.4)';
      ctx.beginPath();
      ctx.arc(c.x, c.y, 8, 0, Math.PI*2); ctx.fill();
    }

    // loot
    for (const it of loot) {
      if (it.taken) continue;
      ctx.fillStyle = it.type==='med'? '#ED6A5A' : '#F3F6F8';
      ctx.beginPath();
      ctx.rect(it.x-5, it.y-5, 10, 10);
      ctx.fill();
    }

    // bullets
    ctx.strokeStyle = '#c8d5ea';
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (const b of bullets) {
      ctx.moveTo(b.x, b.y);
      ctx.lineTo(b.x - Math.cos(b.dir)*6, b.y - Math.sin(b.dir)*6);
    }
    ctx.stroke();

    // entities
    for (const e of entities) {
      if (!e.alive) continue;
      // body
      ctx.fillStyle = e.color;
      ctx.beginPath();
      ctx.arc(e.x, e.y, e.r, 0, Math.PI*2);
      ctx.fill();
      // facing
      ctx.strokeStyle = '#e8eef7';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(e.x, e.y);
      ctx.lineTo(e.x + Math.cos(e.dir)* (e.r+6), e.y + Math.sin(e.dir)* (e.r+6));
      ctx.stroke();
      // hp ring
      ctx.strokeStyle = '#ED6A5A';
      ctx.lineWidth = 3;
      ctx.beginPath();
      const a = Math.max(0, e.hp/100) * Math.PI*2;
      ctx.arc(e.x, e.y, e.r+5, -Math.PI/2, -Math.PI/2 + a);
      ctx.stroke();
    }

    ctx.restore();

    // minimap
    drawMinimap();
  }

  function drawMinimap() {
    const S = minimap.width;
    mctx.clearRect(0,0,S,S);
    mctx.fillStyle = '#0d1220';
    mctx.fillRect(0,0,S,S);
    mctx.strokeStyle = '#223147';
    mctx.strokeRect(0,0,S,S);
    const scale = (S-4)/(WORLD.size/miniZoom);
    const off = { x:(S/2) - (cam.x/ (WORLD.size/2))*(S/2)/miniZoom,
                  y:(S/2) - (cam.y/ (WORLD.size/2))*(S/2)/miniZoom };

    // zone
    mctx.strokeStyle = '#29C2B6';
    mctx.beginPath();
    mctx.arc(off.x + zone.x*scale, off.y + zone.y*scale, zone.r*scale, 0, Math.PI*2);
    mctx.stroke();

    // entities
    for (const e of entities) {
      if (!e.alive) continue;
      mctx.fillStyle = e.isPlayer? '#29C2B6' : '#c8d4f0';
      mctx.fillRect(off.x + e.x*scale -2, off.y + e.y*scale -2, 4, 4);
    }
  }

  // Main loop
  let last = performance.now();
  function tick(now) {
    const dt = Math.min(0.033, (now - last)/1000);
    last = now;
    update(dt);
    draw(dt);
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})(); 
