Shadowdrop Mini — Top‑Down Battle Royale Prototype
====================================================

How to play
-----------
1) Unzip the archive.
2) Open `index.html` in Chrome/Edge/Firefox (double‑click).
3) Controls: WASD to move, Mouse to aim, Left‑click to shoot, Shift to sprint, Space to dash, M to toggle minimap zoom.
4) Survive while the safe zone shrinks. Last one standing wins.

Notes
-----
- This is a lightweight browser prototype (no install).
- ~40 competitors (1 player + 39 bots) with simple AI.
- Loot spawns (medkits, gun upgrades), shrinking safe zone with phase damage.
- If you want a 3D UE5 version, use the design + CSV/JSON tables from the kit and wire up the UE5 classes.

Enjoy!
