import './globals.css';import '../styles/globals.css';import Link from 'next/link';import Image from 'next/image';
export const metadata={title:'AniPro — Anime Streaming',description:'Professional streaming template. Stream legally.'};
export default function RootLayout({children}:{children:React.ReactNode}){
  return (<html lang="en"><body>
    <header className="sticky top-0 z-20 border-b border-neutral-800 bg-neutral-900/70 backdrop-blur">
      <div className="container flex items-center gap-4 py-3">
        <Link href="/" className="flex items-center gap-2 font-extrabold text-white"><Image src="/logo.svg" width={28} height={28} alt="AniPro"/><span>AniPro</span></Link>
        <div className="flex-1" /><nav className="flex items-center gap-2">
          <Link className="btn-ghost" href="/titles">Browse</Link>
          <Link className="btn-ghost" href="/admin">Admin</Link>
        </nav>
      </div></header>
    <main className="container py-6">{children}</main>
    <footer className="border-t border-neutral-800 py-6 text-neutral-400 text-sm"><div className="container">© 2025 AniPro — Demo only. Stream legal content.</div></footer>
  </body></html>);
}