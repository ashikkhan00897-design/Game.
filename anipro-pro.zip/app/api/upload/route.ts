import {NextRequest} from 'next/server';import {PrismaClient} from '@prisma/client';import {spawn} from 'child_process';import {mkdirSync,writeFileSync} from 'fs';import {join} from 'path';const prisma=new PrismaClient();
export async function POST(req:NextRequest){
  const fd=await req.formData(); const file=fd.get('file') as File|null; const episodeId=fd.get('episodeId') as string|null;
  if(!file||!episodeId) return Response.json({ok:false,error:'Missing file or episodeId'},{status:400});
  const buf=Buffer.from(await file.arrayBuffer()); const storage=join(process.cwd(),'public','uploads'); mkdirSync(storage,{recursive:true}); const inputPath=join(storage,`${episodeId}.mp4`); writeFileSync(inputPath,buf);
  const hlsDir=join(process.cwd(),'public','hls',episodeId); mkdirSync(hlsDir,{recursive:true});
  const ff=spawn('ffmpeg',['-y','-i',inputPath,'-preset','veryfast','-start_number','0','-hls_time','4','-hls_list_size','0','-f','hls',join(hlsDir,'index.m3u8')]);
  ff.on('close', async (code)=>{ if(code===0){ await prisma.source.create({data:{episodeId,kind:'hls',url:`/hls/${episodeId}/index.m3u8`}});} });
  await prisma.source.create({data:{episodeId,kind:'mp4',url:`/uploads/${episodeId}.mp4`}});
  return Response.json({ok:true,message:'Upload saved. Transcoding started.'});
}