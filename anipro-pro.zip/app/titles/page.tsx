import {PrismaClient} from '@prisma/client';import Link from 'next/link'; const prisma=new PrismaClient();
export default async function Titles(){ const titles=await prisma.title.findMany({orderBy:{updatedAt:'desc'}}); return (<div>
  <h1 className="text-2xl font-bold mb-4">Browse</h1>
  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
    {titles.map(t=>(<Link key={t.id} href={`/titles/${t.id}`} className="card p-4 hover:bg-neutral-800/60"><div className="font-semibold">{t.name}</div><div className="text-sm text-neutral-400">{t.genres.join(' • ')}</div></Link>))}
    {!titles.length && <div className="text-neutral-400">No titles yet.</div>}
  </div></div>)}