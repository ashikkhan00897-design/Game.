import {PrismaClient} from '@prisma/client';import Link from 'next/link'; const prisma=new PrismaClient();
export default async function TitleDetail({params}:{params:{id:string}}){ const t=await prisma.title.findUnique({where:{id:params.id},include:{seasons:{include:{episodes:true}}}}); if(!t) return <div>Not found</div>;
return (<div className="space-y-4">
  <div className="card p-4"><h1 className="text-2xl font-bold">{t.name} {t.year?`(${t.year})`:''}</h1><p className="text-neutral-400">{t.genres.join(' • ')}</p><p className="mt-2">{t.description}</p></div>
  {t.seasons.map(s=>(<div key={s.id} className="card p-4"><div className="font-semibold mb-2">Season {s.number}</div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">{s.episodes.sort((a,b)=>a.number-b.number).map(ep=>(<Link key={ep.id} href={`/watch/${ep.id}`} className="border border-neutral-800 rounded-xl p-3 hover:bg-neutral-800/50">EP {ep.number}: {ep.name}</Link>))}</div>
  </div>))}
</div>)}