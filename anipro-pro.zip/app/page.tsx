import Link from 'next/link';
export default function Home(){return(<div className="space-y-6">
  <section className="card p-6"><h1 className="text-3xl font-black">Professional anime streaming template</h1>
  <p className="text-neutral-400">Upload & transcode to HLS, manage seasons/episodes, and stream with an adaptive player. <b>For legal content only.</b></p>
  <div className="mt-4 flex gap-3"><Link className="btn" href="/admin">Go to Admin</Link><Link className="btn-ghost" href="/titles">Browse titles</Link></div></section>
</div>)}