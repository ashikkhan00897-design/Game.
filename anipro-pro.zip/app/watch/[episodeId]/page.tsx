'use client';import {useEffect,useRef,useState} from 'react';import Hls from 'hls.js';
export default function Watch({params}:{params:{episodeId:string}}){
  const videoRef=useRef<HTMLVideoElement>(null);const [meta,setMeta]=useState<any>(null);const [levels,setLevels]=useState<any[]>([]);const [cur,setCur]=useState<'auto'|number>('auto');
  useEffect(()=>{(async()=>{
    const data=await fetch(`/api/episode?id=${params.episodeId}`).then(r=>r.json());
    setMeta(data);
    const v=videoRef.current!;const src=data.src;
    if(src?.kind==='hls'){ if(Hls.isSupported()){ const hls=new Hls({maxBufferLength:30}); hls.loadSource(src.url); hls.attachMedia(v); hls.on(Hls.Events.MANIFEST_PARSED,()=>setLevels(hls.levels.map((l,i)=>({i,height:l.height})))); (window as any).__hls=hls; } else { v.src=src.url; } }
    else if(src){ v.src=src.url; }
    const prog=await fetch(`/api/progress?episodeId=${params.episodeId}`).then(r=>r.json()).catch(()=>({current:0}));
    v.currentTime=prog.current||0; v.play().catch(()=>{});
    const id=setInterval(()=>{ if(Number.isFinite(v.duration)) fetch('/api/progress',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({episodeId:params.episodeId,current:Math.floor(v.currentTime),duration:Math.floor(v.duration)})}); },5000);
    return ()=>clearInterval(id);
  })();},[params.episodeId]);
  function setQ(x:any){ setCur(x); const h:(any)=(window as any).__hls; if(h) h.currentLevel = x==='auto'?-1:x; }
  return (<div className="space-y-3">
    <div className="text-sm text-neutral-400">{meta?`${meta.title.name} • ${meta.episode.name}`:'Loading...'}</div>
    <div className="rounded-2xl overflow-hidden border border-neutral-800"><video ref={videoRef} controls playsInline className="w-full bg-black"/></div>
    <div className="flex items-center gap-2"><span className="text-sm text-neutral-400">Quality:</span>
      <button onClick={()=>setQ('auto')} className={`btn-ghost ${cur==='auto'?'border-white':''}`}>Auto</button>
      {levels.map(l=><button key={l.i} onClick={()=>setQ(l.i)} className={`btn-ghost ${cur===l.i?'border-white':''}`}>{l.height}p</button>)}
    </div>
  </div>);
}