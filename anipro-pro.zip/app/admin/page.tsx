import Link from 'next/link';
export default function Admin(){return(<div className="space-y-6"><h1 className="text-2xl font-bold">Admin</h1>
<div className="grid md:grid-cols-2 gap-4">
  <Link href="/admin/titles" className="card p-4 hover:bg-neutral-800/50">Manage Titles</Link>
  <Link href="/admin/upload" className="card p-4 hover:bg-neutral-800/50">Upload & Transcode</Link>
</div>
<p className="text-neutral-400 text-sm">Install FFmpeg. HLS output goes to <code>/public/hls/&lt;episodeId&gt;/index.m3u8</code>.</p></div>)}