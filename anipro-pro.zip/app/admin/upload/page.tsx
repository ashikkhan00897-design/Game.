'use client';import {useSearchParams} from 'next/navigation';import {useState} from 'react';
export default function Upload(){const sp=useSearchParams(); const [episodeId,setEpisodeId]=useState(sp.get('episodeId')||''); const [file,setFile]=useState<File|null>(null); const [status,setStatus]=useState('');
async function submit(e:any){e.preventDefault(); if(!file||!episodeId){alert('Select episode & file');return;} const fd=new FormData(); fd.append('file',file); fd.append('episodeId',episodeId); setStatus('Uploading...'); const res=await fetch('/api/upload',{method:'POST',body:fd}); const js=await res.json(); setStatus(js.ok?'Transcoding started.':'Error: '+js.error);}
return (<div className="space-y-4"><h1 className="text-xl font-bold">Upload & Transcode</h1>
  <form onSubmit={submit} className="card p-3 grid gap-2">
    <input className="input" placeholder="Episode ID" value={episodeId} onChange={e=>setEpisodeId(e.target.value)}/>
    <input className="input" type="file" accept="video/*" onChange={e=>setFile(e.target.files?.[0]||null)}/>
    <button className="btn">Upload</button>
    <div className="text-neutral-400 text-sm">{status}</div>
  </form>
  <p className="text-neutral-400 text-sm">FFmpeg required. Output: <code>/public/hls/&lt;episodeId&gt;/index.m3u8</code>.</p>
</div>)}