'use client';import {useEffect,useState} from 'react';
export default function AdminTitles(){
  const [list,setList]=useState<any[]>([]);const [form,setForm]=useState({name:'',year:'',genres:'Action,Adventure',description:''});
  useEffect(()=>{refresh();},[]); async function refresh(){setList(await fetch('/api/title').then(r=>r.json()));}
  async function create(e:any){e.preventDefault(); await fetch('/api/title',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...form,year:form.year?Number(form.year):null,genres:form.genres.split(',').map(s=>s.trim())})}); setForm({name:'',year:'',genres:'Action,Adventure',description:''}); refresh();}
  return (<div className="space-y-6"><h1 className="text-xl font-bold">Titles</h1>
    <form onSubmit={create} className="grid md:grid-cols-4 gap-2 card p-3">
      <input className="input" placeholder="Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/>
      <input className="input" placeholder="Year" value={form.year} onChange={e=>setForm({...form,year:e.target.value})}/>
      <input className="input" placeholder="Genres (comma)" value={form.genres} onChange={e=>setForm({...form,genres:e.target.value})}/>
      <input className="input" placeholder="Description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/>
      <button className="btn mt-2 md:mt-0">Create</button>
    </form>
    <div className="grid gap-3">{list.map(t=>(<div key={t.id} className="card p-3"><div className="font-semibold">{t.name}</div>
      <div className="text-sm text-neutral-400">{t.genres.join(' • ')} {t.year?`• ${t.year}`:''}</div>
      <div className="text-sm mt-2"><a className="underline" href={`/admin/titles/${t.id}`}>Seasons & Episodes →</a></div></div>))}</div>
  </div>);
}