'use client';import {useEffect,useState} from 'react';import {useParams} from 'next/navigation';
export default function TitleAdmin(){const {id}=useParams() as any; const [data,setData]=useState<any|null>(null);
const [seaN,setSeaN]=useState('1'); const [ep,setEp]=useState({seasonId:'',number:'1',name:'Episode 1'});
useEffect(()=>{ if(id) refresh(); },[id]); async function refresh(){ setData(await fetch('/api/title?id='+id).then(r=>r.json())); }
async function addSeason(){ await fetch('/api/season',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({titleId:id,number:Number(seaN)})}); refresh(); }
async function addEp(e:any){ e.preventDefault(); await fetch('/api/episode',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({seasonId:ep.seasonId,name:ep.name,number:Number(ep.number)})}); setEp(f=>({...f,number:'1',name:'Episode 1'})); refresh(); }
if(!data) return <div>Loading...</div>;
return (<div className="space-y-4"><h1 className="text-xl font-bold">{data.name}</h1>
  <div className="card p-3"><div className="font-semibold mb-2">Add Season</div><div className="flex gap-2"><input className="input w-32" value={seaN} onChange={e=>setSeaN(e.target.value)}/><button className="btn" onClick={addSeason}>Add</button></div></div>
  <div className="card p-3"><div className="font-semibold mb-2">Add Episode</div>
    <form onSubmit={addEp} className="grid md:grid-cols-4 gap-2">
      <select className="input" value={ep.seasonId} onChange={e=>setEp({...ep,seasonId:e.target.value})} required><option value="">Select season</option>{data.seasons.map((s:any)=><option key={s.id} value={s.id}>Season {s.number}</option>)}</select>
      <input className="input" value={ep.number} onChange={e=>setEp({...ep,number:e.target.value})}/>
      <input className="input" value={ep.name} onChange={e=>setEp({...ep,name:e.target.value})}/>
      <button className="btn">Add</button>
    </form>
  </div>
  <div className="space-y-3">{data.seasons.map((s:any)=>(<div key={s.id} className="card p-3">
    <div className="font-semibold">Season {s.number}</div>
    <ul className="mt-2 list-disc list-inside">{s.episodes.sort((a:any,b:any)=>a.number-b.number).map((e:any)=>(<li key={e.id}>EP {e.number}: {e.name} — <a className="underline" href={`/admin/upload?episodeId=${e.id}`}>Upload source</a></li>))}</ul>
  </div>))}</div>
</div>)}